package escope.esprit.escope.Drawer;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import escope.esprit.escope.R;
import escope.esprit.escope.User.UserSessionManager;
import escope.esprit.escope.adapter.PatientAdapter;
import escope.esprit.escope.entities.Patient;
import escope.esprit.escope.utile.Url;

/**
 * A simple {@link Fragment} subclass.
 */
public class ListPatientFragment extends Fragment {
    List<Patient> PatientList;
    UserSessionManager session;

    RecyclerView recyclerView;
    ProgressBar progressBar;
    String HTTP_JSON_URL = Url.URL+"getPatient";
    //String GET_JSON_FROM_SERVER_NAME_TITRE = "titre";
   // String GET_JSON_FROM_SERVER_NAME_DESCRIPTION = "description";
  //  String Image_URL_JSON = "image";
    JsonArrayRequest jsonArrayRequest ;

    RequestQueue requestQueue ;

    View ChildView ;

    int GetItemPosition ;
    RecyclerView.Adapter recyclerViewadapter;
    RecyclerView.LayoutManager layoutManagerOfrecyclerView;
    ArrayList<String> nomPatient;
    ArrayList<String> prenomPatient;
    ArrayList<String> adressePatients;
    ArrayList<String> cinPatients;
    ArrayList<String> genderPatients;
    ArrayList<String> emailPatients;
    ArrayList<String> birthdatePatients;

    List<Patient> ListOfPatientAdapter;
    public ListPatientFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list_patient, container, false);
        PatientList = new ArrayList<>();
        recyclerView = (RecyclerView) view.findViewById(R.id.patient_recyclerView);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar1);

        recyclerView.setHasFixedSize(true);
        layoutManagerOfrecyclerView = new LinearLayoutManager(this.getActivity());

        recyclerView.setLayoutManager(layoutManagerOfrecyclerView);

        progressBar.setVisibility(View.VISIBLE);
        adressePatients = new ArrayList<>();
        birthdatePatients = new ArrayList<>();
        cinPatients=new ArrayList<>();
        genderPatients=new ArrayList<>();
        nomPatient=new ArrayList<>();
        prenomPatient=new ArrayList<>();
        emailPatients=new ArrayList<>();
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.adduser);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment newFragment = new addPatient();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.flcontent, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();            }
        });
        ListOfPatientAdapter=new ArrayList<>();
        JSON_DATA_WEB_CALL();
        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            GestureDetector gestureDetector = new GestureDetector(getActivity(), new GestureDetector.SimpleOnGestureListener() {

                @Override public boolean onSingleTapUp(MotionEvent motionEvent) {

                    return true;
                }

            });
            @Override
            public boolean onInterceptTouchEvent(RecyclerView Recyclerview, MotionEvent motionEvent) {

                ChildView = Recyclerview.findChildViewUnder(motionEvent.getX(), motionEvent.getY());

                if(ChildView != null && gestureDetector.onTouchEvent(motionEvent)) {

                    GetItemPosition = Recyclerview.getChildAdapterPosition(ChildView);

                    Toast.makeText(getActivity(), nomPatient.get(GetItemPosition), Toast.LENGTH_LONG).show();
                }

                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView Recyclerview, MotionEvent motionEvent) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });


        return view;

    }
    public void JSON_DATA_WEB_CALL(){

        jsonArrayRequest = new JsonArrayRequest(HTTP_JSON_URL,

                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        progressBar.setVisibility(View.GONE);

                        JSON_PARSE_DATA_AFTER_WEBCALL(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.e("Error: "+error.toString(), error);
                    }
                });
       /* {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                HashMap<String, String> user = session.getUserDetails();
                String email = user.get(UserSessionManager.KEY_EMAIL);

                params.put("email", email);
                return params;
            }
        }*/



        requestQueue = Volley.newRequestQueue(getActivity());

        requestQueue.add(jsonArrayRequest);

    }

    public void JSON_PARSE_DATA_AFTER_WEBCALL(JSONArray array){

        for(int i = 0; i<array.length(); i++) {

            Patient GetDataAdapter2 = new Patient();
            System.out.println( "hello");
            JSONObject json = null;
            try {
                json = array.getJSONObject(i);

                GetDataAdapter2.setFirstname(json.getString("firstName"));
                GetDataAdapter2.setLastname(json.getString("lastName"));
               // GetDataAdapter2.setImage(Url.URLL+"media/"+json.getString(Image_URL_JSON));
                GetDataAdapter2.setEmail(json.getString("email"));
                GetDataAdapter2.setGender(json.getString("gender"));
                GetDataAdapter2.setCin(json.getString("cin"));
                GetDataAdapter2.setBirthdate(json.getString("birthDate"));
                GetDataAdapter2.setAdresse(json.getString("adresse"));
              //  GetDataAdapter2.setAdresse(json.getString("phoneNumber"));

                prenomPatient.add(json.getString("firstName"));
                nomPatient.add(json.getString("lasteName"));
                adressePatients.add(json.getString("adresse"));
                emailPatients.add(json.getString("email"));
                prenomPatient.add(json.getString("firstName"));
                genderPatients.add(json.getString("gender"));
                cinPatients.add(json.getString("cin"));
                birthdatePatients.add(json.getString("birthDate"));
              //  eventImage.add(Url.URLL+"media/"+json.getString(Image_URL_JSON));

            } catch (JSONException e) {

                e.printStackTrace();
            }
            PatientList.add(GetDataAdapter2);
        }

        recyclerViewadapter = new PatientAdapter(getActivity(),PatientList);

        recyclerView.setAdapter(recyclerViewadapter);


    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
