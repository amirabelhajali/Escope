package escope.esprit.escope.Drawer;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import escope.esprit.escope.R;


public class addPatient extends Fragment {



    EditText txtEmail,txtNom,txtAdresse,txtNum,txtCodePostale ;
    ImageView edit;
    public addPatient() {
        // Required empty public constructor
    }



    public static Profile newInstance(String param1, String param2) {
        Profile fragment = new Profile();


        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_addpatient, container, false);

        txtEmail = (EditText) view.findViewById(R.id.emailtv);
        txtNom = (EditText) view.findViewById(R.id.nomtv);
        txtAdresse = (EditText) view.findViewById(R.id.adressetv);
        txtNum = (EditText) view.findViewById(R.id.phonetv);
        txtCodePostale = (EditText) view.findViewById(R.id.codePostaleTv);
        edit = (ImageView) view.findViewById(R.id.fab);

edit.setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v) {

    }
});


        return  view;
    }
    }




