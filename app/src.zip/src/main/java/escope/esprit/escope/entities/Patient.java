package escope.esprit.escope.entities;

/**
 * Created by amira on 04/12/2017.
 */

public class Patient {

    private int id;
    private String firstname;
    private String lastname;
    private String cin;
    private String birthdate;
    private String email;
    private String adresse;
    private String status;
    private String gender;
    private String createdAt;
    private String updatedAt;
    public Patient() {
    }

    public Patient(String firstname, String lastname, String cin, String birthdate, String email, String adresse, String status, String gender) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.cin = cin;
        this.birthdate = birthdate;
        this.email = email;
        this.adresse = adresse;
        this.gender = gender;
        this.status = status;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}
