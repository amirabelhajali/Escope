package escope.esprit.escope.User;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import escope.esprit.escope.Drawer.MainActivity;
import escope.esprit.escope.R;
import escope.esprit.escope.utile.Url;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    private static final int REQUEST_SIGNUP = 0;
    private UserSessionManager session;
    String   newString;
    String URL = Url.URLL+"login.php";
    public static final String PREFS_USER = "prefs_user";
    EditText emailText;
    EditText passwordText;
    Button loginButton;
    TextView signupLink;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        session = new UserSessionManager(getApplicationContext());
        Toast.makeText(getApplicationContext(),
                "User Login Status: " +session.isUserLoggedIn(),
                Toast.LENGTH_LONG).show();
        emailText=(EditText) findViewById(R.id.login);
        passwordText=(EditText) findViewById(R.id.password);
        loginButton=(Button) findViewById(R.id.loginBtm);

        signupLink=(TextView) findViewById(R.id.signup_link);
        SharedPreferences preferences = getSharedPreferences(PREFS_USER, MODE_PRIVATE);
        String emailPrefs = preferences.getString("email", null);
        String passwordPrefs = preferences.getString("password", null);

        if (emailPrefs != null) {
            emailText.setText(emailPrefs);
            passwordText.setText(passwordPrefs);


        }

        loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Start the Signup activity
               // login();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
                // Open SharedPrefs File in Edit Mode
                SharedPreferences.Editor editor = getSharedPreferences(PREFS_USER, MODE_PRIVATE).edit();
                editor.putString("email", emailText.getText().toString());
                editor.putString("password", passwordText.getText().toString());
                editor.commit();
                //INSERT INTO DATABASE
             /*   UserDao dao = new UserDao(getApplicationContext());
                User user = new User();
                user.setEmail(emailText.getText().toString());
                user.setPassword(passwordText.getText().toString());


                long idInsert = dao.insertCigarette(user);
                Toast.makeText(getApplicationContext(), "ID = "+idInsert, Toast.LENGTH_SHORT).show();

*/



            }
        });

        signupLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

               // Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
               // startActivityForResult(intent, REQUEST_SIGNUP);
            }
        });
    }


    public void login() {
        Log.d(TAG, "Login");

        if (!validate()) {
            onLoginFailed();
            return;
        }

        loginButton.setEnabled(false);

        final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this,
                R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();


        // TODO: Implement your own authentication logic here.

        StringRequest request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){

            @Override
            public void onResponse(String response)
            {
                System.out.println(response);
                try {
                JSONObject res = new JSONObject(response);
                String err=res.getString("error");
                String message=res.getString("message");

                    if(err.equals("false")){
                    Toast.makeText(LoginActivity.this,message, Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(LoginActivity.this, LoginActivity.class);
                    startActivity(intent);
                }


                else if(err.equals("true")){
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_LONG).show();

                    //response json

                      //  System.out.println(response);

                        //JSONObject connectedUserData = new JSONObject(response);
                        User user = new User(res.getString("remember_token"),
                                res.getString("firstName"),
                                res.getString("lastName"),
                                res.getString("email"),
                                res.getString("role"),
                                res.getString("birthDate")


                        );
                        System.out.println(user.getFirstname());
                        session.createUserLoginSession(user.getTokens(),user.getFirstname(),user.getLastname(),user.getEmail(),user.getRole(),user.getBirthdate());

                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        System.out.println("sucessssssssssssss");
                        // Add new Flag to start new Activity
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);

                        // finish();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        VolleyLog.e("Error: "+error.toString(), error);
                    }
                })
        {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<String, String>();

                params.put("email", emailText.getText().toString());
                params.put("password", passwordText.getText().toString());
                return params;
            }
        };

        RequestQueue rQueue = Volley.newRequestQueue(LoginActivity.this);
        rQueue.add(request);

        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        // On complete call either onLoginSuccess or onLoginFailed
                        onLoginSuccess();
                        // onLoginFailed();
                        progressDialog.dismiss();
                    }
                }, 3000);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SIGNUP) {
            if (resultCode == RESULT_OK) {

                // TODO: Implement successful signup logic here

                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);

                this.finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        // disable going back to the MainActivity
        moveTaskToBack(true);
    }

    public void onLoginSuccess() {
        loginButton.setEnabled(true);
        finish();


    }

    public void onLoginFailed() {
        Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

        loginButton.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;

        String email = emailText.getText().toString();
        String motdepasse = passwordText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailText.setError("enter a valid email address");
            valid = false;

        } else {
            emailText.setError(null);
        }

        if (motdepasse.isEmpty() || motdepasse.length() < 4 || motdepasse.length() > 10) {
            passwordText.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            passwordText.setError(null);
        }

        return valid;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (emailText.getText().toString()== emailText.getText().toString() && (passwordText.getText().toString()==passwordText.getText().toString())){
            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);

        }
    }
}


