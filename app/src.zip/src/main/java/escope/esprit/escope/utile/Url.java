package escope.esprit.escope.utile;

/**
 * Created by utilisateur on 08/12/2017.
 */

public class Url {
  public static final   String URLL = "http://172.16.120.148/escopeAndroid/script/";
  public static final   String URL = "http://172.16.120.148:8000/apii/";

}
